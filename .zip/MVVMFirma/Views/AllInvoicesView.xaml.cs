﻿namespace MVVMFirma.Views
{
    public partial class AllInvoicesView : AllViewBase
    {
        public AllInvoicesView()
        {
            InitializeComponent();
        }
    }
}

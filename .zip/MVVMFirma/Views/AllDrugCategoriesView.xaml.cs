﻿namespace MVVMFirma.Views
{
    public partial class AllDrugCategoriesView : AllViewBase
    {
        public AllDrugCategoriesView()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace MVVMFirma.Views
{
    public partial class AllProducersView : AllViewBase
    {
        public AllProducersView()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMFirma.Models.EntitiesForView
{
    public class ProducerForAllView
    {
        public int ID_Producenta { get; set; }
        public string Nazwa_Producenta { get; set; }
        public string Telefon { get; set; }
        public string Ulica { get; set; }
        public string Miasto { get; set; }
        public string Kod_Pocztowy { get; set; }
    }
}

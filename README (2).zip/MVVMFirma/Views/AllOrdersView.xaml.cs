﻿using MVVMFirma.Views;

namespace MVVMFirma.Views
{
    public partial class AllOrdersView : AllViewBase
    {
        public AllOrdersView()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace MVVMFirma.Views
{
    public partial class AllReceiptsView : AllViewBase
    {
        public AllReceiptsView()
        {
            InitializeComponent();
        }
    }
}

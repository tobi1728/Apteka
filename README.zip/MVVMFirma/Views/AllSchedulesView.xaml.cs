﻿namespace MVVMFirma.Views
{
    public partial class AllSchedulesView : AllViewBase
    {
        public AllSchedulesView()
        {
            InitializeComponent();
        }
    }
}

﻿namespace MVVMFirma.Views
{
    public partial class AllSuppliersView : AllViewBase
    {
        public AllSuppliersView()
        {
            InitializeComponent();
        }
    }
}

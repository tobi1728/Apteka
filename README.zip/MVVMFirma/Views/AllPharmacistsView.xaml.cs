﻿using System.Windows.Controls;

namespace MVVMFirma.Views
{
    public partial class AllPharmacistsView : AllViewBase
    {
        public AllPharmacistsView()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMFirma.Models.EntitiesForView
{
    public class PharmacistForAllView
    {
        public int ID_Farmaceuty { get; set; }
        public string Imię { get; set; }
        public string Nazwisko { get; set; }
        public string Numer_Licencji { get; set; }

        public string Pracownik { get; set; }

    }
}

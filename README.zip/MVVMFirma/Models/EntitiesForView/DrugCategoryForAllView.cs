﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMFirma.Models.EntitiesForView
{
    public class DrugCategoryForAllView
    {
        public int ID_Kategorii { get; set; }
        public string Nazwa_Kategorii { get; set; }
        public string Opis { get; set; }
    }
}
